package com.klef.jfsd.springboot.JANATA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SevatNetApplication {

	public static void main(String[] args) {
		SpringApplication.run(SevatNetApplication.class, args);
		System.out.println("Sevnet Portal Is Running...");
	}

}
